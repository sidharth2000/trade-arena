package com.tradearena.notificationservice.service;

import com.tradearena.notificationservice.dto.NotificationRequest;
import com.tradearena.notificationservice.model.NotificationType;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Set;

@Service
public class EmailService {

    private final JavaMailSender mailSender;

    @Value("${trade-arena.mail.from}")
    private String fromAddress;

    private static final Set<NotificationType> EMAIL_TYPES = Set.of(
            NotificationType.AUCTION_WIN,
            NotificationType.PAYMENT_REMINDER,
            NotificationType.OUTBID,
            NotificationType.PAYMENT_SUCCESS,
            NotificationType.ACCOUNT_RESTRICTED,
            NotificationType.FALLBACK_OFFER,
            NotificationType.BID_PLACED
    );

    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    public boolean isEmailType(NotificationType type) {
        return EMAIL_TYPES.contains(type);
    }

    // ── Option A: Notification Service builds the email ──────────────────
    @Async("emailTaskExecutor")
    public void sendEmail(NotificationRequest req) {
        if (req.getUserEmail() == null || req.getUserEmail().isBlank()) return;
        if (!isEmailType(req.getType())) return;

        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            helper.setFrom(fromAddress);
            helper.setTo(req.getUserEmail());
            helper.setSubject(subjectFor(req.getType(), req.getProductTitle()));
            helper.setText(bodyFor(req), true);
            mailSender.send(mimeMessage);
        } catch (MessagingException e) {
            System.err.println("Email failed for type=" + req.getType() + ": " + e.getMessage());
        }
    }

    // ── Option B: Caller provides full HTML ──────────────────────────────
    @Async("emailTaskExecutor")
    public void sendHtmlEmail(List<String> to, List<String> cc,
                              String subject, String htmlBody) {
        if (to == null || to.isEmpty()) {
            System.err.println("sendHtmlEmail called with empty 'to' list — skipping.");
            return;
        }
        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            helper.setFrom(fromAddress);
            helper.setTo(to.toArray(new String[0]));
            if (cc != null && !cc.isEmpty()) {
                helper.setCc(cc.toArray(new String[0]));
            }
            helper.setSubject(subject);
            helper.setText(htmlBody, true);
            mailSender.send(mimeMessage);
        } catch (MessagingException e) {
            System.err.println("HTML email failed: " + e.getMessage());
        }
    }

    // ── Subject builder ───────────────────────────────────────────────────
    private String subjectFor(NotificationType type, String productTitle) {
        String suffix = (productTitle != null && !productTitle.isBlank())
                ? " – " + productTitle : "";
        return switch (type) {
            case AUCTION_WIN        -> "🎉 You won the auction" + suffix;
            case OUTBID             -> "⚡ You've been outbid" + suffix;
            case PAYMENT_REMINDER   -> "⏰ Payment reminder" + suffix;
            case PAYMENT_SUCCESS    -> "✅ Payment confirmed" + suffix;
            case ACCOUNT_RESTRICTED -> "⚠️ Account restricted – Trade Arena";
            case FALLBACK_OFFER     -> "🔔 Second-chance offer available" + suffix;
            case BID_PLACED         -> "💰 New bid on your listing" + suffix;
            default                 -> "Trade Arena Notification";
        };
    }

    // ── Main body router — picks the right template ───────────────────────
    private String bodyFor(NotificationRequest req) {
        return switch (req.getType()) {
            case OUTBID             -> outbidTemplate(req);
            case AUCTION_WIN        -> auctionWinTemplate(req);
            case PAYMENT_REMINDER   -> paymentReminderTemplate(req);
            case PAYMENT_SUCCESS    -> paymentSuccessTemplate(req);
            case ACCOUNT_RESTRICTED -> accountRestrictedTemplate(req);
            case FALLBACK_OFFER     -> fallbackOfferTemplate(req);
            case BID_PLACED         -> bidPlacedTemplate(req);
            default                 -> genericTemplate(req);
        };
    }

    // ── Shared layout wrapper ─────────────────────────────────────────────
    private String wrap(String headerColor, String headerEmoji,
                        String headerTitle, String content) {
        return """
            <div style="margin:0;padding:0;background-color:#f4f4f4;font-family:Arial,sans-serif;">
              <table width="100%%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center" style="padding:30px 10px;">
                    <table width="600" cellpadding="0" cellspacing="0"
                           style="background:#ffffff;border-radius:8px;
                                  box-shadow:0 2px 8px rgba(0,0,0,0.08);overflow:hidden;">

                      <!-- HEADER -->
                      <tr>
                        <td style="background:%s;padding:30px;text-align:center;">
                          <div style="font-size:36px;">%s</div>
                          <h1 style="color:#ffffff;margin:10px 0 0;font-size:22px;
                                     font-weight:700;letter-spacing:0.5px;">%s</h1>
                        </td>
                      </tr>

                      <!-- BRAND BAR -->
                      <tr>
                        <td style="background:#1a1a2e;padding:8px;text-align:center;">
                          <span style="color:#ffffff;font-size:13px;
                                       font-weight:600;letter-spacing:2px;">
                            TRADE ARENA
                          </span>
                        </td>
                      </tr>

                      <!-- CONTENT -->
                      <tr>
                        <td style="padding:30px 40px;">
                          %s
                        </td>
                      </tr>

                      <!-- FOOTER -->
                      <tr>
                        <td style="background:#f9f9f9;padding:20px;
                                   text-align:center;border-top:1px solid #eeeeee;">
                          <p style="margin:0;font-size:12px;color:#999999;">
                            This is an automated message from Trade Arena. Please do not reply.
                          </p>
                          <p style="margin:6px 0 0;font-size:11px;color:#bbbbbb;">
                            &copy; 2026 Trade Arena. All rights reserved.
                          </p>
                        </td>
                      </tr>

                    </table>
                  </td>
                </tr>
              </table>
            </div>
            """.formatted(headerColor, headerEmoji, headerTitle, content);
    }

    // ── Info box helper ───────────────────────────────────────────────────
    private String infoBox(String bgColor, String... rows) {
        StringBuilder sb = new StringBuilder();
        sb.append("<table width='100%%' cellpadding='0' cellspacing='0' style='")
                .append("background:").append(bgColor).append(";")
                .append("border-radius:6px;margin:20px 0;padding:0;'>")
                .append("<tr><td style='padding:20px;'>");
        for (String row : rows) {
            sb.append(row);
        }
        sb.append("</td></tr></table>");
        return sb.toString();
    }

    private String infoRow(String label, String value) {
        return "<p style='margin:6px 0;font-size:14px;color:#333333;'>"
                + "<span style='color:#666666;'>" + label + ":</span> "
                + "<strong>" + value + "</strong></p>";
    }

    private String ctaButton(String url, String label, String color) {
        return "<div style='text-align:center;margin:25px 0;'>"
                + "<a href='" + url + "' style='background:" + color + ";color:#ffffff;"
                + "padding:14px 32px;text-decoration:none;border-radius:6px;"
                + "font-size:15px;font-weight:600;display:inline-block;'>"
                + label + "</a></div>";
    }

    // ── Templates ─────────────────────────────────────────────────────────

    private String outbidTemplate(NotificationRequest req) {
        String product = req.getProductTitle() != null ? req.getProductTitle() : "this item";
        String amount  = req.getBidAmount() != null
                ? String.format("&euro;%.2f", req.getBidAmount()) : "—";

        String content = """
            <p style="font-size:16px;color:#333333;margin:0 0 10px;">
              Hi there,
            </p>
            <p style="font-size:15px;color:#555555;margin:0 0 20px;">
              Someone just placed a higher bid on <strong>%s</strong>.
              Don't miss out — place a new bid to stay in the lead!
            </p>
            """.formatted(escape(product))
                + infoBox("#fff8e1",
                infoRow("Product", escape(product)),
                infoRow("Current Highest Bid", amount))
                + ctaButton("http://localhost:5173/products/"
                        + (req.getReferenceId() != null ? req.getReferenceId() : ""),
                "Bid Again Now", "#f59e0b");

        return wrap("#f59e0b", "⚡", "You've Been Outbid!", content);
    }

    private String auctionWinTemplate(NotificationRequest req) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm");
        String product  = req.getProductTitle() != null ? req.getProductTitle() : "the item";
        String amount   = req.getBidAmount() != null
                ? String.format("&euro;%.2f", req.getBidAmount()) : "—";
        String deadline = req.getPaymentDeadline() != null
                ? req.getPaymentDeadline().format(dtf) : "within 24 hours";

        String content = """
            <p style="font-size:16px;color:#333333;margin:0 0 10px;">
              Congratulations! 🎉
            </p>
            <p style="font-size:15px;color:#555555;margin:0 0 20px;">
              You have won the auction for <strong>%s</strong>.
              Please complete your payment before the deadline to secure your item.
            </p>
            """.formatted(escape(product))
                + infoBox("#f0fdf4",
                infoRow("Product", escape(product)),
                infoRow("Winning Bid", amount),
                infoRow("Payment Deadline", deadline))
                + ctaButton("http://localhost:5173/orders", "Complete Payment Now", "#16a34a");

        return wrap("#16a34a", "🎉", "You Won the Auction!", content);
    }

    private String paymentReminderTemplate(NotificationRequest req) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm");
        String product  = req.getProductTitle() != null ? req.getProductTitle() : "your item";
        String deadline = req.getPaymentDeadline() != null
                ? req.getPaymentDeadline().format(dtf) : "very soon";

        String content = """
            <p style="font-size:16px;color:#333333;margin:0 0 10px;">
              Hi there,
            </p>
            <p style="font-size:15px;color:#555555;margin:0 0 20px;">
              This is a reminder that your payment for <strong>%s</strong> is due soon.
              Failure to pay may result in account restrictions.
            </p>
            """.formatted(escape(product))
                + infoBox("#fff7ed",
                infoRow("Product", escape(product)),
                infoRow("Payment Due By", deadline))
                + ctaButton("http://localhost:5173/orders", "Pay Now", "#ea580c");

        return wrap("#ea580c", "⏰", "Payment Reminder", content);
    }

    private String paymentSuccessTemplate(NotificationRequest req) {
        String product = req.getProductTitle() != null ? req.getProductTitle() : "your item";
        String amount  = req.getBidAmount() != null
                ? String.format("&euro;%.2f", req.getBidAmount()) : "—";

        String content = """
            <p style="font-size:16px;color:#333333;margin:0 0 10px;">
              Great news!
            </p>
            <p style="font-size:15px;color:#555555;margin:0 0 20px;">
              Your payment for <strong>%s</strong> has been successfully received.
              The seller will be in touch shortly.
            </p>
            """.formatted(escape(product))
                + infoBox("#f0fdf4",
                infoRow("Product", escape(product)),
                infoRow("Amount Paid", amount))
                + ctaButton("http://localhost:5173/orders", "View Order", "#16a34a");

        return wrap("#16a34a", "✅", "Payment Confirmed!", content);
    }

    private String accountRestrictedTemplate(NotificationRequest req) {
        String content = """
            <p style="font-size:16px;color:#333333;margin:0 0 10px;">
              Hi there,
            </p>
            <p style="font-size:15px;color:#555555;margin:0 0 20px;">
              Your Trade Arena account has been temporarily restricted due to
              multiple missed payments. You will not be able to place bids
              until the restriction is lifted.
            </p>
            <p style="font-size:15px;color:#555555;margin:0 0 20px;">
              If you believe this is a mistake, please contact our support team.
            </p>
            """ + ctaButton("http://localhost:5173/support",
                "Contact Support", "#dc2626");

        return wrap("#dc2626", "⚠️", "Account Restricted", content);
    }

    private String fallbackOfferTemplate(NotificationRequest req) {
        String product = req.getProductTitle() != null ? req.getProductTitle() : "an item";
        String amount  = req.getBidAmount() != null
                ? String.format("&euro;%.2f", req.getBidAmount()) : "—";

        String content = """
            <p style="font-size:16px;color:#333333;margin:0 0 10px;">
              Good news!
            </p>
            <p style="font-size:15px;color:#555555;margin:0 0 20px;">
              The original winner did not complete their payment for
              <strong>%s</strong>. As the next highest bidder,
              you now have the opportunity to purchase this item at your bid price!
            </p>
            """.formatted(escape(product))
                + infoBox("#eff6ff",
                infoRow("Product", escape(product)),
                infoRow("Your Bid", amount))
                + ctaButton("http://localhost:5173/products/"
                        + (req.getReferenceId() != null ? req.getReferenceId() : ""),
                "Claim This Item", "#2563eb");

        return wrap("#2563eb", "🔔", "Second-Chance Offer!", content);
    }

    private String bidPlacedTemplate(NotificationRequest req) {
        String product = req.getProductTitle() != null ? req.getProductTitle() : "your listing";
        String amount  = req.getBidAmount() != null
                ? String.format("&euro;%.2f", req.getBidAmount()) : "—";

        String content = """
            <p style="font-size:16px;color:#333333;margin:0 0 10px;">
              Hi there,
            </p>
            <p style="font-size:15px;color:#555555;margin:0 0 20px;">
              A buyer just placed a new bid on your listing <strong>%s</strong>.
              Check your auction to see all current bids!
            </p>
            """.formatted(escape(product))
                + infoBox("#faf5ff",
                infoRow("Product", escape(product)),
                infoRow("New Bid Amount", amount))
                + ctaButton("http://localhost:5173/my-listings",
                "View My Listings", "#7c3aed");

        return wrap("#7c3aed", "💰", "New Bid on Your Listing!", content);
    }

    private String genericTemplate(NotificationRequest req) {
        String content = """
            <p style="font-size:15px;color:#555555;margin:0 0 20px;">%s</p>
            """.formatted(escape(req.getMessage()));

        return wrap("#2c7a4b", "🔔", "Trade Arena Notification", content);
    }

    // ── XSS protection ────────────────────────────────────────────────────
    private String escape(String text) {
        if (text == null) return "";
        return text.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;");
    }
}